<?php  // Moodle configuration file

unset($CFG);
global $CFG;
$CFG = new stdClass();

$CFG->dbtype    = 'mysqli';
$CFG->dblibrary = 'native';
$CFG->dbhost    = 'localhost';
$CFG->dbname    = 'moodle_unilurio';
$CFG->dbuser    = 'root';
$CFG->dbpass    = '12345678';
$CFG->prefix    = 'mdl_';
$CFG->dboptions = array (
  'dbpersist' => 0,
  'dbport' => 30066,
  'dbsocket' => '',
  'dbcollation' => 'utf8_general_ci',
);

$CFG->wwwroot   = 'http://localhost:8088/moodle-unilurio';
$CFG->dataroot  = '/home/helena/bitnami/lampstack/apache2/moodledataunilurio';
$CFG->admin     = 'admin';

$CFG->directorypermissions = 0777;

$CFG->keeptempdirectoriesonbackup = true;

require_once(dirname(__FILE__) . '/lib/setup.php');

// There is no php closing tag in this file,
// it is intentional because it prevents trailing whitespace problems!
