<?php

echo 'One, my little hobbit, never installs malicisous add-ons';
